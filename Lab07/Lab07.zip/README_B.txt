in password_crack.py, instead of leaving salt as empty, salt is assigned a random 40 character value.
in bank.py, authenticate method is used to verify input passwords.