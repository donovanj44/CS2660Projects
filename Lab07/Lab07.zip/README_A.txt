Small program that checks password hashes against common dictionary terms, allowing for unauthorized access.

The program reads in a wordlist, reads in a list of users and their password hashes, then checks every common word against every hash.