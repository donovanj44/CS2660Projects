import sqlite3

def create_search_query(account_id: int, search_term: str, conn):
    """
    Secure version using parameterized queries to prevent SQL injection.
    Uses the provided database connection.

    :param account_id: int - The user's account ID.
    :param search_term: str - The term to search within transaction memos.
    :param conn: sqlite3.Connection - The active database connection.
    :return: list - The query results.
    """

    cursor = conn.cursor()
    conn.commit()

    # Secure query using parameterized queries
    query = 'SELECT * FROM trnsaction WHERE account_id = ? AND memo LIKE ?'
    params = (account_id, f"%{search_term}%")

    cursor.execute(query, params)
    results = cursor.fetchall()

    return results
