"""
This module is used to isolate the code for each lesson.
"""
